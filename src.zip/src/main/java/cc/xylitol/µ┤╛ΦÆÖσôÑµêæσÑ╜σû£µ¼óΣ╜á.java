package cc.xylitol;

public class 派蒙哥我好喜欢你 {
    public static void 派蒙哥我好崇拜你(){
        System.out.println("派蒙哥 Treasure弟好崇拜你");
    }
}
