package net.netease;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Map;
import net.minecraft.network.Packet;

public class GsonUtil {
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public static String toJson(JsonObject jsonObject) {
        return gson.toJson(jsonObject);
    }

    public static String toJson(Packet<?> jsonObject) {
        return gson.toJson(jsonObject);
    }

    public static JsonObject fromJson(String s) {
        return gson.fromJson(s, JsonObject.class);
    }

    public static JsonElement toJsonTree(Object s) {
        return gson.toJsonTree(s);
    }

    public static Object fromJson(JsonElement e, Class<?> c) {
        return gson.fromJson(e, c);
    }

    public static Object fromJson(String s, Class<?> c) {
        return gson.fromJson(s, c);
    }

    public static String toJson(Map map) {
        return gson.toJson(map);
    }
}

