package net.netease;

import cc.xylitol.event.annotations.EventTarget;
import cc.xylitol.event.impl.events.EventPacket;
import cc.xylitol.event.impl.events.EventTick;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.network.PacketBuffer;
import net.netease.packet.Channel;
import net.netease.packet.GermPacket;
import top.fl0wowp4rty.phantomshield.annotations.Native;

@Native
public class PacketProcessor {
    private final Channel registerChannel = new Channel("REGISTER");
    private final Channel germChannel = new Channel("germplugin-netease");
    private final Channel hyt0Channel = new Channel("hyt0");
    private static final String REGISTER_MESSAGE = "FML|HS\u0000FML\u0000FML|MP\u0000FML\u0000FORGE\u0000germplugin-netease\u0000hyt0\u0000armourers";
    public static byte[] heyPixelRegister;
    public static byte[] heyPixelGameInfo;
    private final Map<Integer, GermPacket> registry = new HashMap<Integer, GermPacket>();
    public static PacketProcessor INSTANCE;
    private boolean needRegisterMods;
    private int ticks;

    public static native int getProcessID();

    private native void reg(String var1);

    public static native String getArgs(int var0);

    public PacketProcessor() {
        this.reg("yedecheng");
    }

    private native void register(GermPacket var1);

    @EventTarget
    public native void onTick(EventTick var1);

    @EventTarget
    private native void onPacket(EventPacket var1);

    public native void sendPacket(GermPacket var1);

    public native void processPacket(PacketBuffer var1);

    static {
        PacketProcessor.killhuorong9();
    }

    private static native /* synthetic */ void killhuorong9();
}

