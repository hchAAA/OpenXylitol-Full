package net.optifine;

public class VersionCheckThread
extends Thread {
    public VersionCheckThread() {
        super("VersionCheck");
    }

    @Override
    public void run() {
    }
}

