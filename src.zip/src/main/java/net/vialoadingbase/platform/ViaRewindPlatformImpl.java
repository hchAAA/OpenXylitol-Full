package net.vialoadingbase.platform;

import cc.xylitol.Client;
import com.viaversion.viarewind.api.ViaRewindPlatform;
import java.io.File;
import java.util.logging.Logger;
import net.minecraft.item.ItemSword;
import net.vialoadingbase.ViaLoadingBase;

public class ViaRewindPlatformImpl
implements ViaRewindPlatform {
    public ViaRewindPlatformImpl(File directory) {
        this.init(new File(directory, "viarewind.yml"));
    }

    public Logger getLogger() {
        return ViaLoadingBase.LOGGER;
    }

    @Override
    public File getDataFolder() {
        return null;
    }

    public boolean isSword() {
        if (Client.mc.thePlayer == null || Client.mc.theWorld == null) {
            return false;
        }
        return Client.mc.thePlayer.getCurrentEquippedItem() != null && Client.mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemSword;
    }
}

